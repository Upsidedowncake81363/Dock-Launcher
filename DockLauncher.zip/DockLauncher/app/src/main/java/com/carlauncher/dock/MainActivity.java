package com.carlauncher.dock;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.ComponentName;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.os.Bundle;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * A tiny home screen: the system wallpaper, a clock, and a dock of up to 10 apps.
 * No libraries, no permissions, no background work.
 *
 * Wallpaper: the window shows whatever wallpaper the system has, so any wallpaper app
 * (Backdrops, Phonewalls, ...) works by setting the wallpaper from inside that app.
 */
public class MainActivity extends Activity {

    private static final int MAX_APPS = 10;
    private static final int DIALOG_THEME = android.R.style.Theme_Material_Dialog_Alert;

    // Dock geometry, in dp.
    private static final int DOCK_MARGIN = 28;
    private static final int DOCK_PAD = 14;
    private static final int ARROW_W = 48;
    private static final int TILE_W = 132;
    private static final int TILE_GAP = 12;

    private static final String PREFS = "dock";
    private static final String KEY_APPS = "apps";
    private static final String KEY_WALLPAPER_APP = "wallpaper_app";
    private static final String SEP = ";";

    private final List<ComponentName> apps = new ArrayList<>();
    private SharedPreferences prefs;
    private PackageManager pm;
    private FrameLayout root;
    private LinearLayout tiles;
    private View prevBtn;
    private View nextBtn;
    private AlertDialog dialog;
    private int start = 0;    // index of the first visible dock slot
    private int perPage = 6;  // how many slots fit on screen

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(R.layout.activity_main);

        pm = getPackageManager();
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        root = findViewById(R.id.root);
        tiles = findViewById(R.id.tiles);
        prevBtn = findViewById(R.id.prev);
        nextBtn = findViewById(R.id.next);

        prevBtn.setOnClickListener(v -> {
            start -= perPage;
            renderDock();
        });
        nextBtn.setOnClickListener(v -> {
            start += perPage;
            renderDock();
        });
        findViewById(R.id.btn_wallpaper).setOnClickListener(v -> openWallpaperApp());
        findViewById(R.id.btn_settings).setOnClickListener(v -> showMenu());

        // Fit the dock to the real screen width as soon as it is known (or changes).
        root.addOnLayoutChangeListener((v, left, top, right, bottom, oldLeft, oldTop, oldRight, oldBottom) -> {
            if (right - left != oldRight - oldLeft) {
                root.post(this::renderDock);
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadApps();
        renderDock();
    }

    @Override
    protected void onPause() {
        super.onPause();
        dismissDialog();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        start = 0; // Home pressed again: back to the first page (onResume re-renders)
    }

    @Override
    public void onBackPressed() {
        // A home screen has nowhere to go back to.
    }

    // ---------------------------------------------------------------- storage

    private void loadApps() {
        apps.clear();
        for (String s : prefs.getString(KEY_APPS, "").split(SEP)) {
            ComponentName cn = ComponentName.unflattenFromString(s);
            if (cn != null && isInstalled(cn) && apps.size() < MAX_APPS) {
                apps.add(cn);
            }
        }
    }

    private void saveApps() {
        StringBuilder sb = new StringBuilder();
        for (ComponentName cn : apps) {
            if (sb.length() > 0) sb.append(SEP);
            sb.append(cn.flattenToString());
        }
        prefs.edit().putString(KEY_APPS, sb.toString()).apply();
    }

    private boolean isInstalled(ComponentName cn) {
        try {
            pm.getActivityInfo(cn, 0);
            return true;
        } catch (PackageManager.NameNotFoundException e) {
            return false;
        }
    }

    // ------------------------------------------------------------------- dock

    private void renderDock() {
        DisplayMetrics dm = getResources().getDisplayMetrics();
        int width = root.getWidth() > 0 ? root.getWidth() : dm.widthPixels;
        int slot = dp(TILE_W + TILE_GAP);
        int avail = width - dp(2 * (DOCK_MARGIN + DOCK_PAD));
        int count = apps.size() + (apps.size() < MAX_APPS ? 1 : 0); // +1 for the "Add app" tile

        // Show everything if it fits; otherwise make room for the two arrows and page.
        perPage = Math.max(1, avail / slot);
        boolean paged = count > perPage;
        if (paged) {
            perPage = Math.max(1, (avail - 2 * dp(ARROW_W + 8)) / slot);
        }

        int maxStart = Math.max(0, count - perPage);
        start = Math.max(0, Math.min(start, maxStart));

        tiles.removeAllViews();
        int end = Math.min(count, start + perPage);
        for (int i = start; i < end; i++) {
            tiles.addView(i < apps.size() ? appTile(i) : addTile());
        }

        prevBtn.setVisibility(paged ? View.VISIBLE : View.GONE);
        nextBtn.setVisibility(paged ? View.VISIBLE : View.GONE);
        setArrow(prevBtn, start > 0);
        setArrow(nextBtn, start < maxStart);
    }

    private View appTile(final int index) {
        final ComponentName cn = apps.get(index);
        View tile = LayoutInflater.from(this).inflate(R.layout.tile, tiles, false);
        ImageView icon = tile.findViewById(R.id.icon);
        TextView label = tile.findViewById(R.id.label);
        try {
            ActivityInfo info = pm.getActivityInfo(cn, 0);
            icon.setImageDrawable(info.loadIcon(pm));
            label.setText(info.loadLabel(pm));
        } catch (PackageManager.NameNotFoundException e) {
            label.setText(cn.getPackageName());
        }
        sizeTile(tile);
        tile.setOnClickListener(v -> launch(cn));
        tile.setOnLongClickListener(v -> {
            showTileMenu(index);
            return true;
        });
        return tile;
    }

    private View addTile() {
        View tile = LayoutInflater.from(this).inflate(R.layout.tile, tiles, false);
        ImageView icon = tile.findViewById(R.id.icon);
        TextView label = tile.findViewById(R.id.label);
        icon.setImageResource(R.drawable.ic_add);
        label.setText(R.string.add_app);
        sizeTile(tile);
        tile.setOnClickListener(v -> pickApp(false));
        return tile;
    }

    private void sizeTile(View tile) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(TILE_W), dp(92));
        lp.setMargins(dp(TILE_GAP / 2f), 0, dp(TILE_GAP / 2f), 0);
        tile.setLayoutParams(lp);
    }

    private void setArrow(View arrow, boolean enabled) {
        arrow.setEnabled(enabled);
        arrow.setAlpha(enabled ? 1f : 0.3f);
    }

    private void addApp(ComponentName cn) {
        if (apps.size() >= MAX_APPS) {
            Toast.makeText(this, R.string.dock_full, Toast.LENGTH_LONG).show();
            return;
        }
        if (!apps.contains(cn)) apps.add(cn);
        saveApps();
        start = Integer.MAX_VALUE; // jump to the page that shows the new app
        renderDock();
    }

    private void move(int from, int to) {
        Collections.swap(apps, from, to);
        saveApps();
        if (to < start) {
            start = to;
        } else if (to >= start + perPage) {
            start = to - perPage + 1;
        }
        renderDock();
    }

    private void remove(int index) {
        apps.remove(index);
        saveApps();
        renderDock();
    }

    // ---------------------------------------------------------------- actions

    private void launch(ComponentName cn) {
        Intent intent = new Intent(Intent.ACTION_MAIN);
        intent.addCategory(Intent.CATEGORY_LAUNCHER);
        intent.setComponent(cn);
        intent.addFlags(Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
        startSafely(intent, R.string.cant_open);
    }

    private void startSafely(Intent intent, int errorRes) {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try {
            startActivity(intent);
        } catch (ActivityNotFoundException | SecurityException e) {
            Toast.makeText(this, errorRes, Toast.LENGTH_LONG).show();
        }
    }

    private void openWallpaperApp() {
        ComponentName cn = ComponentName.unflattenFromString(prefs.getString(KEY_WALLPAPER_APP, ""));
        if (cn != null && isInstalled(cn)) {
            launch(cn);
        } else {
            pickApp(true);
        }
    }

    // ---------------------------------------------------------------- dialogs

    private void showMenu() {
        final String[] names = {
                getString(R.string.menu_wallpaper_app),
                getString(R.string.menu_default_home),
                getString(R.string.menu_android_settings),
                getString(R.string.menu_clear_dock)
        };
        final Runnable[] actions = {
                () -> pickApp(true),
                () -> startSafely(new Intent(Settings.ACTION_HOME_SETTINGS), R.string.unavailable),
                () -> startSafely(new Intent(Settings.ACTION_SETTINGS), R.string.unavailable),
                this::confirmClear
        };
        display(new AlertDialog.Builder(this, DIALOG_THEME)
                .setItems(names, (d, which) -> actions[which].run()));
    }

    private void confirmClear() {
        display(new AlertDialog.Builder(this, DIALOG_THEME)
                .setMessage(R.string.clear_confirm)
                .setPositiveButton(R.string.clear, (d, which) -> {
                    apps.clear();
                    saveApps();
                    start = 0;
                    renderDock();
                })
                .setNegativeButton(android.R.string.cancel, null));
    }

    private void showTileMenu(final int index) {
        final List<String> names = new ArrayList<>();
        final List<Runnable> actions = new ArrayList<>();
        if (index > 0) {
            names.add(getString(R.string.move_left));
            actions.add(() -> move(index, index - 1));
        }
        if (index < apps.size() - 1) {
            names.add(getString(R.string.move_right));
            actions.add(() -> move(index, index + 1));
        }
        names.add(getString(R.string.remove));
        actions.add(() -> remove(index));

        display(new AlertDialog.Builder(this, DIALOG_THEME)
                .setItems(names.toArray(new String[0]), (d, which) -> actions.get(which).run()));
    }

    /** Lists every launchable app. Used to add dock apps and to choose the wallpaper app. */
    private void pickApp(final boolean forWallpaper) {
        Intent query = new Intent(Intent.ACTION_MAIN);
        query.addCategory(Intent.CATEGORY_LAUNCHER);

        final List<AppItem> items = new ArrayList<>();
        for (ResolveInfo info : pm.queryIntentActivities(query, 0)) {
            ComponentName cn = new ComponentName(info.activityInfo.packageName, info.activityInfo.name);
            if (getPackageName().equals(cn.getPackageName())) continue;
            if (!forWallpaper && apps.contains(cn)) continue;
            items.add(new AppItem(cn, info.loadLabel(pm).toString(), info));
        }
        Collections.sort(items, (a, b) -> a.label.compareToIgnoreCase(b.label));

        display(new AlertDialog.Builder(this, DIALOG_THEME)
                .setTitle(forWallpaper ? R.string.pick_wallpaper_app : R.string.add_app)
                .setAdapter(new AppAdapter(items), (d, which) -> {
                    ComponentName chosen = items.get(which).cn;
                    if (forWallpaper) {
                        prefs.edit().putString(KEY_WALLPAPER_APP, chosen.flattenToString()).apply();
                        launch(chosen);
                    } else {
                        addApp(chosen);
                    }
                })
                .setNegativeButton(android.R.string.cancel, null));
    }

    private void display(AlertDialog.Builder builder) {
        dismissDialog();
        dialog = builder.create();
        dialog.show();
    }

    private void dismissDialog() {
        if (dialog != null) {
            dialog.dismiss();
            dialog = null;
        }
    }

    private int dp(float value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    // ---------------------------------------------------------------- helpers

    private static final class AppItem {
        final ComponentName cn;
        final String label;
        final ResolveInfo info;

        AppItem(ComponentName cn, String label, ResolveInfo info) {
            this.cn = cn;
            this.label = label;
            this.info = info;
        }
    }

    /** Icons are loaded lazily, only for the rows currently on screen. */
    private class AppAdapter extends BaseAdapter {
        private final List<AppItem> items;

        AppAdapter(List<AppItem> items) {
            this.items = items;
        }

        @Override
        public int getCount() {
            return items.size();
        }

        @Override
        public Object getItem(int position) {
            return items.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            View row = convertView != null
                    ? convertView
                    : LayoutInflater.from(MainActivity.this).inflate(R.layout.row_app, parent, false);
            AppItem item = items.get(position);
            ImageView icon = row.findViewById(R.id.icon);
            TextView label = row.findViewById(R.id.label);
            icon.setImageDrawable(item.info.loadIcon(pm));
            label.setText(item.label);
            return row;
        }
    }
}
