# No special rules needed: the app has no libraries and no reflection.
