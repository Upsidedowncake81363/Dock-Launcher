# Dock Launcher

A small home screen for Android 8+ head units: your system wallpaper, a clock, and a dock of up to 10 apps.
No internet, no permissions, no libraries.

## Build the APK (pick one)

**Android Studio (PC):** File > Open > this folder. Wait for Gradle sync, then Build > Build APK(s).
The file lands in `app/build/outputs/apk/debug/app-debug.apk`.

**GitHub, nothing to install:** create a repo and upload everything in this folder (including the hidden
`.github` folder). Open the Actions tab > Build APK > Run workflow. When it finishes, download the
`DockLauncher-apk` artifact and unzip it.

## Install on the head unit

1. Copy the APK to a USB stick and open it from the unit's file manager. Allow "unknown sources" if asked.
2. Open **Dock Launcher** from the unit's app list.
3. Press Home, choose Dock Launcher, then **Just once** to test.
4. Happy with it? Press Home again and choose **Always**.

To go back: Settings > Apps > Dock Launcher > Clear defaults, or uninstall it.

## Using it

- **Add an app:** tap the + tile. Up to 10.
- **Arrows:** appear only when the apps do not all fit. Tap to page.
- **Reorder or remove:** long-press an app.
- **Wallpaper:** tap the picture button and pick your wallpaper app once (Backdrops, Phonewalls, anything).
  Set a wallpaper inside that app. The launcher shows the system wallpaper, so it updates by itself.
- **Sliders button:** change wallpaper app, default home app, Android settings, clear dock.

Add Settings and any factory apps you still need (Radio, Bluetooth) to the dock first, so you can always reach them.
